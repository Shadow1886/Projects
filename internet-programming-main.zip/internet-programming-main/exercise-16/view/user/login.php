<?php include ("view/common/header.php"); ?>

<?php include ("view/common/footer.php"); ?>
